<?php

return [
    'hq' => 'HEAD QUARTER',
    'branch' => 'REPRESENTATIVE OFFICES',
    'partner' => 'SUCCESS PARTNER IN AGRICULTURE SOLUTION',

];
