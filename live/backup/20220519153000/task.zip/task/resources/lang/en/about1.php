<?php

return [
    'title' => 'PRODUCTION',
    'title1' => 'Material Technology',
    'desc1' => 'International standard raw materials where each material has the best quality in accordance with the required plantations equipment specifications',

    'title2' => 'Material Processing Technology With Details',
    'desc2' => 'New technologies and computerization in the steels processing to produce high quality tools',

    'title3' => 'Our Production Team',
    'desc3' => 'Supported by highly qualified workers in every production process. Starting from forming materials, forming blades, processing steel, until finishing',

    'title4' => 'Designed For Wise Users',
    'desc4' => 'Focus on every detail design of our products to provide best user experiences through research and development',

];
