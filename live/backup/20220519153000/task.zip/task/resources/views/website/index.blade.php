@extends('layouts.website')

<!-- styles start -->
@section('style')
@endsection
<!-- styles end -->

<!-- js start -->
@section('js')
@endsection
<!-- js end -->

<!-- content start -->
@section('content')

<!-- home Section Start -->
<section id="home">
@include('website.index-item')
</section>
<!-- home Section End -->

@endsection
<!-- content end -->

