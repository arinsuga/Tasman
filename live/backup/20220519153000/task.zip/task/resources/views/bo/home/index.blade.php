@extends('layouts.appbo')

@section('content')

<div class="container">
    
<div class="container">
    <div class="box" style="border: none;">
        <img style="width: 90%;" src="{{ asset('img/'.config('a1.uiux.logo_landscape')) }}" alt="">
    </div>
</div>

</div>


@endsection
