

<?php $__env->startSection('content_title', 'Master Project Add'); ?>

<?php $__env->startSection('toolbar'); ?>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('masterproject.index')); ?>">
        <i class="fas fa-lg fa-arrow-left"></i>
    </a>
</li>

<li class="nav-item">
    <a onclick="event.preventDefault(); document.getElementById('frmData').submit();"
       class="nav-link" href="#">
        <i class="fas fa-lg fa-save"></i>
    </a>
</li>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<form role="form" id="frmData" method="POST" action="<?php echo e(route('masterproject.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div style="display: flex; justify-content=center;">
        <?php echo $__env->make('bo.masterproject.data-field-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <?php echo $__env->make('bo.masterproject._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/masterproject/create.blade.php ENDPATH**/ ?>