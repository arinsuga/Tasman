

<div class="row">
    <div class="col-lg-4 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-info">
            <div class="inner">
                <h3>150</h3>

                <p>Suport</p>
            </div>
            <div class="icon">
                <i class="fa fa-concierge-bell"></i>
            </div>
            <a href="#" class="small-box-footer">View Detail <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>

    <div class="col-lg-4 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-success">
            <div class="inner">
                <h3>150</h3>

                <p>Maintenance</p>
            </div>
            <div class="icon">
                <i class="fa fa-tools"></i>
            </div>
            <a href="#" class="small-box-footer">View Detail <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>

    <div class="col-lg-4 col-sm-12">
        <!-- small box -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h3>5</h3>

                <p>Project</p>
            </div>
            <div class="icon">
                <i class="fa fa-tasks"></i>
            </div>

            <a href="#" class="small-box-footer">View Detail <i class="fas fa-arrow-circle-right"></i></a>
        </div>

    </div>

</div>