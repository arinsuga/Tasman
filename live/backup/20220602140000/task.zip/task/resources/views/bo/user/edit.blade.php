@extends('layouts.appbo')

@section('content')
    <h1>EDIT</h1>
@endsection
