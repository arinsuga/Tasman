<?php

return [
    'home' => 'Beranda',
    'about' => 'Tentang Kami',
    'product' => 'Produk',
    'branch' => 'Lokasi Cabang',
    'event' => 'Berita & Acara',
    'contact' => 'Kontak Kami',
    'shop' => 'Belanja',
    'language' => 'Bahasa',
];
