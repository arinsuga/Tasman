<div class="listrow listrow-between">
    <div class="listrow-item">
        @include('website.components.logo-playstore')
    </div>

    <div class="listrow-item">
        @include('website.components.logo-instagram')
    </div>

    <div class="listrow-item">
        @include('website.components.logo-youtube')
    </div>

    <div class="listrow-item">
        @include('website.components.logo-fbfanpage')
    </div>
</div>