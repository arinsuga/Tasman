<div class="modal fade" id="modal-delete">
<div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title">Konfirmasi Hapus Data</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <p>Proses Hapus Data</p>
    </div>
    <div class="modal-footer justify-content-between">
        <button id="modalClose" type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button onclick="deleteActivity();" type="button" class="btn btn-primary">Hapus</button>
    </div>
    </div>
    <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/project/modal-delete.blade.php ENDPATH**/ ?>