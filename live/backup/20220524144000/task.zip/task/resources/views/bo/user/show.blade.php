@extends('layouts.appbo')

@section('content')
    <h1>SHOW</h1>
@endsection
